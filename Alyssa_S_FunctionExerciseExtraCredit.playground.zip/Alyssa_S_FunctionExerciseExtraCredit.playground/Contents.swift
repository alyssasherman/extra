import UIKit

struct ContactInfo {
    var name = "Alyssa Sherman"
    var number = "773-953-4531"
    var email = "sherman8197@gmail.com"
}

let myContactInfo = ContactInfo()

print("My name is \(myContactInfo.name) and you can contact me via \(myContactInfo.number) or \(myContactInfo.email)")
